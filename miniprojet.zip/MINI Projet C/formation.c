#include "formateur.h"
#include "formation.h"
#include "candidat.h"
#include "administration.h"

int isLeapYearF(int year) {
    return ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
}

int isValidDateF(struct date *date) {
    if (date->mois < 1 || date->mois > 12) {
        return 0; // Invalid month
    }

    const int daysInMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (date->jour < 1 || date->jour > daysInMonth[date->mois]) {
        if (date->mois == 2 && isLeapYearF(date->annee) && date->jour == 29) {
            return 1;
        } else {
            return 0;
        }
    }

    return 1; // Valid date
}

int afficherListeFormation() {
    FILE *fichier = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Formations.txt", "r");
    if (fichier == NULL) {
        perror("Erreur ouverture du fichier.\n");
        return 0;
    }

    fseek(fichier, 0, SEEK_END);
    long fichierSize = ftell(fichier);
    rewind(fichier);

    char *contenuFile = (char *)malloc(fichierSize + 1);

    fread(contenuFile, 1, fichierSize, fichier);
    contenuFile[fichierSize] = '\0';

    printf(" __________________________\n");
    printf("|  Liste des formations:   |\n");
    printf("|__________________________|\n");
    printf(" %s", contenuFile);

    if (fichierSize == 0) {
        printf("\t-->Il n'y a aucune formation.\n");
        return 0;
    }

    free(contenuFile);
    fclose(fichier);
    return 1;
}

void supprimerFormation() {
    char formationSupprime[100];
    afficherListeFormation();
    const char *fichierPath = "C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Formations.txt";

    printf("\n __________________________\n");
    printf("|    Nom de la Formation:  |\n");
    printf("|__________________________|\n");

    scanf(" %[^\n]", formationSupprime);

    FILE *fichier = fopen(fichierPath, "r");
    if (fichier == NULL) {
        perror("Erreur lors de l'ouverture du fichier original");
        exit(EXIT_FAILURE);
    }

    FILE *fichierTemp = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", "w");
    if (fichierTemp == NULL) {
        perror("Erreur lors de l'ouverture du fichier temporaire");
        fclose(fichier);
        exit(EXIT_FAILURE);
    }

    fseek(fichier, 0, SEEK_END);
    long fichierSize = ftell(fichier);
    rewind(fichier);

    char *contentFile = (char *)malloc(fichierSize + 1);

    fread(contentFile, 1, fichierSize, fichier);
    contentFile[fichierSize] = '\0';

    char *ligne = strtok(contentFile, "\n");

    while (ligne != NULL) {
        char formationNom[100];

        if (sscanf(ligne, "Titre de la formation:|%99[^|]|", formationNom) == 1) {
            if (strcmp(formationNom, formationSupprime) != 0) {
                fprintf(fichierTemp, "%s\n", ligne);
            }
        }

        ligne = strtok(NULL, "\n");
    }

    fclose(fichier);
    fclose(fichierTemp);
    free(contentFile);

    if (remove(fichierPath) != 0) {
        remove("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt");
        perror("Erreur lors de la suppression du fichier original");
        exit(EXIT_FAILURE);
    }

    if (rename("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", fichierPath) != 0) {
        perror("Erreur lors du renommage du fichier temporaire");
        exit(EXIT_FAILURE);
    }

    afficherListeFormation();
}


void ajouterFormation() {
    struct Formation *formation = (struct Formation *)malloc(sizeof(struct Formation));

    if (formation == NULL) {
        perror("Memory allocation failed");
        exit(EXIT_FAILURE);
    }

    int error = 0;

    while (error == 0) {
        printf("\t --->Titre de la formation: ");
        scanf(" %[^\n]", formation->titre);

        printf("\t --->Durée de la formation: (heures) ");
        scanf("%d", &formation->duree);

        printf("\t --->Commence le:\n");
        printf("\t \t--->Jour: ");
        scanf("%d", &formation->dateDebut.jour);
        printf("\t \t--->Mois: ");
        scanf("%d", &formation->dateDebut.mois);
        printf("\t \t--->Année: ");
        scanf("%d", &formation->dateDebut.annee);

        if (!isValidDateF(&formation->dateDebut)) {
            printf("Date debut invalide.\n");
            error = 1;
            break;
        }

        printf("\t --->Termine le:\n");
        printf("\t \t--->Jour: ");
        scanf("%d", &formation->dateFin.jour);
        printf("\t \t--->Mois: ");
        scanf("%d", &formation->dateFin.mois);
        printf("\t \t--->Année: ");
        scanf("%d", &formation->dateFin.annee);

        if (!isValidDateF(&formation->dateFin)) {
            printf("Date fin invalide.\n");
            error = 1;
            break;
        }

        if (formation->dateDebut.annee > formation->dateFin.annee ||
            (formation->dateDebut.annee == formation->dateFin.annee &&
             (formation->dateDebut.mois > formation->dateFin.mois ||
              (formation->dateDebut.mois == formation->dateFin.mois && formation->dateDebut.jour > formation->dateFin.jour)))) {
            printf("Les dates sont invalides.\n");
            error = 1;
            break;
        }

        printf("\t --->Assurée par:(NOM Prénom) ");
        scanf(" %[^\n]", formation->formateur);

        printf("\t --->Prix: ");
        scanf("%f", &formation->prix);

        FILE *fichier = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Formations.txt", "a");

        if (fichier != NULL) {
            fprintf(fichier, "Titre de la formation:|%s| Durée de la formation:|%d H| Commence le:|%d/%d/%d| Termine le:|%d/%d/%d| Le formateur:|%s| Prix:|%.2f dt|\n",
                    formation->titre, formation->duree, formation->dateDebut.jour, formation->dateDebut.mois, formation->dateDebut.annee,
                    formation->dateFin.jour, formation->dateFin.mois, formation->dateFin.annee, formation->formateur, formation->prix);
            fclose(fichier);
            free(formation);

            printf("La formation a été ajoutée avec succès.\n");
            break;
        } else {
            perror("Erreur lors de l'ouverture du fichier.\n");
            free(formation);
            exit(EXIT_FAILURE);
        }
    }
}
