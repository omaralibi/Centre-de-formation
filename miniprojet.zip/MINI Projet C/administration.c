#include "formateur.h"
#include "formation.h"
#include "candidat.h"
#include "administration.h"

void afficherListeInscriptions() {
    FILE *fichier = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Inscriptions.txt", "r");

    if (fichier == NULL) {
        perror("Erreur ouverture du fichier des inscriptions.\n");
        return;
    }

    fseek(fichier, 0, SEEK_END);
    long fichierSize = ftell(fichier);
    rewind(fichier);

    if (fichierSize == 0) {
        printf("\t-->Il n'y a aucune inscription.\n");
        fclose(fichier);
        return;
    }

    char *contenuFile = (char *)malloc(fichierSize + 1);

    if (contenuFile == NULL) {
        perror("Memory allocation error.\n");
        fclose(fichier);
        return;
    }

    fread(contenuFile, 1, fichierSize, fichier);
    contenuFile[fichierSize] = '\0';

    printf(" __________________________\n");
    printf("| Liste des inscriptions:  |\n");
    printf("|__________________________|\n");

    char *line = strtok(contenuFile, "\n");
    while (line != NULL) {
        printf("%s\n", line);
        line = strtok(NULL, "\n");
    }

    fclose(fichier);
    free(contenuFile);
}


void changerStatutInscription() {
    const char *fichierPath = "C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Inscriptions.txt";

    afficherListeInscriptions();
    FILE *fichier = fopen(fichierPath, "r");
    if (fichier == NULL) {
        perror("Erreur ouverture du fichier.\n");
        exit(EXIT_FAILURE);
    }


    FILE *fichierTemp = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", "w");
    if (fichierTemp == NULL) {
        perror("Erreur ouverture du fichier temporaire.\n");
        fclose(fichier);
        exit(EXIT_FAILURE);
    }

    fseek(fichier, 0, SEEK_END);
    long fichierSize = ftell(fichier);
    rewind(fichier);

    char *contenuFile = (char *)malloc(fichierSize + 1);

    if (contenuFile == NULL) {
        perror("Memory allocation error.\n");
        fclose(fichier);
        fclose(fichierTemp);
        exit(EXIT_FAILURE);
    }else if ((fichierSize)!=0){
printf("\n__________________________\n");
printf("|    Nom de la Formation:  |\n");
printf("|__________________________|\n");

char nomFormation[100];
scanf(" %[^\n]", nomFormation);

    if (inscriptionValide(nomFormation)) {
    printf("\n_______________________________\n");
    printf("| Nom et Pr�nom du Candidat:    |\n");
    printf("|_______________________________|\n");

    char nomCandidat[100], nomFormateur[100];
    scanf(" %[^\n]", nomCandidat);

    printf("\n_________________________________\n");
    printf("| NOM et Pr�nom du Formateur:     |\n");
    printf("|_________________________________|\n");

    scanf(" %[^\n]", nomFormateur);

    fread(contenuFile, 1, fichierSize, fichier);
    contenuFile[fichierSize] = '\0';

    char *ligne = strtok(contenuFile, "\n");

    while (ligne != NULL) {
        if (strstr(ligne, nomFormation) != NULL && strstr(ligne, nomFormateur) != NULL && strstr(ligne, nomCandidat) != NULL) {
            char *posNonPayee = strstr(ligne, "_Non pay�e_");
            if (posNonPayee != NULL) {
                strncpy(posNonPayee, "_Pay�e_", 8);
            }
        }

        fprintf(fichierTemp, "%s\n", ligne);
        ligne = strtok(NULL, "\n");
    }

    fclose(fichier);
    fclose(fichierTemp);
    free(contenuFile);

    if (remove(fichierPath) != 0) {
        perror("Erreur suppression du fichier original.\n");
        exit(EXIT_FAILURE);
    }

    if (rename("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", fichierPath) != 0) {
        perror("Erreur renommage du fichier temporaire.\n");
        exit(EXIT_FAILURE);
    }}}
}


int afficherListeCandidatAd() {
    FILE *fichier = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Candidats.txt", "r");

    if (fichier == NULL) {
        perror("Erreur ouverture du fichier.\n");
        return 0;
    }

    fseek(fichier, 0, SEEK_END);
    long fichierSize = ftell(fichier);
    rewind(fichier);

    if (fichierSize == 0) {
        printf("\t-->Il n'y a aucun candidat.\n");
        fclose(fichier);
        return 0;
    }

    char *contenuFile = (char *)malloc(fichierSize + 1);

    if (contenuFile == NULL) {
        perror("Memory allocation error.\n");
        fclose(fichier);
        return 0;
    }

    fread(contenuFile, 1, fichierSize, fichier);
    contenuFile[fichierSize] = '\0';

    printf(" __________________________\n");
    printf("|  Liste des candidats:    |\n");
    printf("|__________________________|\n");

    char *line = strtok(contenuFile, "\n");
    while (line != NULL) {
        printf("%s\n", line);
        line = strtok(NULL, "\n");
    }

    fclose(fichier);
    free(contenuFile);
    return 1;
}
int afficherListeFormateurAd() {
    FILE *fichier = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Formateurs.txt", "r");

    if (fichier == NULL) {
        perror("Erreur ouverture du fichier.\n");
        return 0;
    }

    fseek(fichier, 0, SEEK_END);
    long fichierSize = ftell(fichier);
    rewind(fichier);

    if (fichierSize == 0) {
        printf("\t-->Il n'y a aucun formateur.\n");
        fclose(fichier);
        return 0 ;
    }

    char *contenuFile = (char *)malloc(fichierSize + 1);

    if (contenuFile == NULL) {
        perror("Memory allocation error.\n");
        fclose(fichier);
        return 0;
    }

    fread(contenuFile, 1, fichierSize, fichier);
    contenuFile[fichierSize] = '\0';

    printf(" __________________________\n");
    printf("|  Liste des formateurs:   |\n");
    printf("|__________________________|\n");

    char *line = strtok(contenuFile, "\n");
    while (line != NULL) {
        printf("%s\n", line);
        line = strtok(NULL, "\n");
    }

    fclose(fichier);
    free(contenuFile);
            return 1;
}

void supprimerFormateur() {
    char formateurSupprime[100];
    afficherListeFormateurAd();
if(afficherListeFormateurAd()== 1){
    const char *fichierPath = "C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Formateurs.txt";

    printf("\n __________________________\n");
    printf("| NOM Pr�nom du Formateur: |\n");
    printf("|__________________________|\n");

    if (scanf(" %[^\n]", formateurSupprime) != 1) {
        perror("Erreur lors de la lecture du nom du formateur");
        exit(EXIT_FAILURE);
    }

    FILE *fichier = fopen(fichierPath, "r");
    FILE *fichierTemp = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", "w");

    if (fichier == NULL || fichierTemp == NULL) {
        perror("Erreur lors de l'ouverture des fichiers");
        exit(EXIT_FAILURE);
    }

    fseek(fichier, 0, SEEK_END);
    long fichierSize = ftell(fichier);
    rewind(fichier);

    char *contenuFile = (char *)malloc(fichierSize + 1);

    if (contenuFile == NULL) {
        perror("Memory allocation error");
        fclose(fichier);
        fclose(fichierTemp);
        return;
    }

    fread(contenuFile, 1, fichierSize, fichier);
    contenuFile[fichierSize] = '\0';

    char *ligne = strtok(contenuFile, "\n");
    while (ligne != NULL) {
        char formateurNom[100];
        if (sscanf(ligne, "NOM Pr�nom:|%[^|]|", formateurNom) == 1) {
            if (strcmp(formateurNom, formateurSupprime) != 0) {
                fprintf(fichierTemp, "%s\n", ligne);
            }
        }
        ligne = strtok(NULL, "\n");
    }

    fclose(fichier);
    fclose(fichierTemp);
    free(contenuFile);

    if (remove(fichierPath) != 0) {
        perror("Erreur lors de la suppression du fichier original");
        exit(EXIT_FAILURE);
    }

    if (rename("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", fichierPath) != 0) {
        perror("Erreur lors du renommage du fichier temporaire");
        exit(EXIT_FAILURE);
    }
}}

void supprimerCandidat() {
    char candidatSupprime[100];
    afficherListeCandidatAd();
if (afficherListeCandidatAd()== 1){
    const char *fichierPath = "C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Candidats.txt";

    printf("\n __________________________\n");
    printf("| NOM Pr�nom du Candidat:  |\n");
    printf("|__________________________|\n");

    if (scanf(" %[^\n]", candidatSupprime) != 1) {
        perror("Erreur lors de la lecture du nom du candidat");
        exit(EXIT_FAILURE);
    }

    FILE *fichier = fopen(fichierPath, "r");
    FILE *fichierTemp = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", "w");

    if (fichier == NULL || fichierTemp == NULL) {
        perror("Erreur lors de l'ouverture des fichiers");
        exit(EXIT_FAILURE);
    }

    fseek(fichier, 0, SEEK_END);
    long fichierSize = ftell(fichier);
    rewind(fichier);

    char *contenuFile = (char *)malloc(fichierSize + 1);

    if (contenuFile == NULL) {
        perror("Memory allocation error");
        fclose(fichier);
        fclose(fichierTemp);
        return;
    }

    fread(contenuFile, 1, fichierSize, fichier);
    contenuFile[fichierSize] = '\0';

    char *ligne = strtok(contenuFile, "\n");
    while (ligne != NULL) {
        char candidatNom[100];
        if (sscanf(ligne, "NOM Pr�nom:|%[^|]|", candidatNom) == 1) {
            if (strcmp(candidatNom, candidatSupprime) != 0) {
                fprintf(fichierTemp, "%s\n", ligne);
            }
        }
        ligne = strtok(NULL, "\n");
    }

    fclose(fichier);
    fclose(fichierTemp);
    free(contenuFile);

    if (remove(fichierPath) != 0) {
        perror("Erreur lors de la suppression du fichier original");
        exit(EXIT_FAILURE);
    }

    if (rename("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", fichierPath) != 0) {
        perror("Erreur lors du renommage du fichier temporaire");
        exit(EXIT_FAILURE);
    }
}}



void menuAdministration(){
    int choix;
                  do {
                  printf(" ________________________________________________________\n");
                  printf("|---------- __   __  _______  __    _  __   __ ----------|\n");
                  printf("|----------|  |_|  ||       ||  |  | ||  | |  |----------|\n");
                  printf("|----------|       ||    ___||   |_| ||  | |  |----------|\n");
                  printf("|----------|       ||   |___ |       ||  |_|  |----------|\n");
                  printf("|----------|       ||    ___||  _    ||       |----------|\n");
                  printf("|----------| ||_|| ||   |___ | | |   ||       |----------|\n");
                  printf("|----------|_|   |_||_______||_|  |__||_______|----------|\n");
                  printf("|--------------------------------------------------------|\n");
                  printf("|1. Consulter la liste des formateurs.                   |\n");
                  printf("|2. Consulter la liste des formations.                   |\n");
                  printf("|3. Consulter la liste des candidats.                    |\n");
                  printf("|4. Consulter la liste des insciptions.                  |\n");
                  printf("|5. Payement inscription.                                |\n");
                  printf("|6. Effacer un candidat.                                 |\n");
                  printf("|7. Effacer un formateur.                                |\n");
                  printf("|0. Retour                                               |\n");
                  printf("|________________________________________________________|\n");
                  printf("\t --->Choix: ");
                      scanf("%d", &choix);

                      switch (choix) {
                          case 1:
                              afficherListeFormateurAd();
                              break;
                          case 2:
                              afficherListeFormation();
                              break;
                          case 3:
                              afficherListeCandidatAd();
                              break;
                          case 4:
                                  afficherListeInscriptions();
                                  break;
                          case 5:
                            changerStatutInscription();
                              break;


                          case 6:
                             supprimerCandidat();
                              break;
                          case 7:
                              supprimerFormateur();
                              break;
                          case 0:
                              printf("Retour au menu principal.\n");
                              break;
                          default:
                              printf("Choix invalide. Veuillez r�essayer.\n");
                      }
                  } while (choix != 0);}
