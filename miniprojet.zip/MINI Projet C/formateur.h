#ifndef FORMATEUR_H
#define FORMATEUR_H

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

struct Formateur {
    char nom[20];
    char prenom[20];
    char username[20];
    char motDePasse[20];
    char specialite[20];
};

void menuFormateur();
void inscriptionFormateur();
void identificationFormateur();
void afficherListeCandidatfo();
void afficherListeFormationfo();
void menuOperationFormateur();
int identificateurCorrectfo(const char *username, const char *motDePasse);

#endif // FORMATEUR_H
