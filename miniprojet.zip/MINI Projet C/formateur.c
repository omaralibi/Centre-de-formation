#include "formateur.h"
#include "formation.h"
#include "candidat.h"
#include "administration.h"

void afficherListeFormationfo() {
    char formateurNom[100];
    printf("\n__________________________\n");
    printf("| Votre NOM et Prénom:     |\n");
    printf("|__________________________|\n");
    scanf(" %[^\n]", formateurNom);

    FILE *file = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Formations.txt", "r");

    if (file == NULL) {
        perror("Erreur ouverture du fichier.\n");
        return;
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    rewind(file);

    if (fileSize <= 0) {
        printf("\t-->Il n'y a aucune formation.\n");
        fclose(file);
        return;
    }

    char *contenuFile = (char *)malloc(fileSize + 1);

    if (contenuFile == NULL) {
        perror("Memory allocation error.\n");
        fclose(file);
        return;
    }

    fread(contenuFile, 1, fileSize, file);
    contenuFile[fileSize] = '\0';

    printf(" __________________________\n");
    printf("|  Liste des formations:   |\n");
    printf("|__________________________|\n");

    char *ligne = strtok(contenuFile, "\n");
    while (ligne != NULL) {
        if (strstr(ligne, formateurNom) != NULL) {
            printf("%s\n", ligne);
        }
        ligne = strtok(NULL, "\n");
    }

    free(contenuFile);
    fclose(file);
}



void afficherListeCandidatfo() {
    char formateurNom[100];
    printf("\n__________________________\n");
    printf("| Votre NOM et Prénom:     |\n");
    printf("|__________________________|\n");
    scanf(" %[^\n]", formateurNom);

    FILE *file = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Inscriptions.txt", "r");

    if (file == NULL) {
        perror("Erreur ouverture du fichier.\n");
        return;
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    rewind(file);

    if (fileSize <= 0) {
        printf("\t-->Il n'y a aucun candidat.\n");
        fclose(file);
        return;
    }

    char *contenuFile = (char *)malloc(fileSize + 1);

    if (contenuFile == NULL) {
        perror("Memory allocation error.\n");
        fclose(file);
        return;
    }

    fread(contenuFile, 1, fileSize, file);
    contenuFile[fileSize] = '\0';

    printf(" _____________________________________________________\n");
    printf("|  Liste des candidats inscrits à votre formation:    |\n");
    printf("|_____________________________________________________|\n");

    char *ligne = strtok(contenuFile, "\n");
    while (ligne != NULL) {
        if (strstr(ligne, formateurNom) != NULL){
                printf("%s\n", ligne);
            }
            ligne = strtok(NULL, "\n");
        }



    fclose(file);
    free(contenuFile);
}

int identificateurCorrectfo(const char *username, const char *motDePasse) {
    FILE *file = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Formateurs.txt", "r");

    if (file == NULL) {
        perror("Erreur ouverture du fichier.\n");
        return 0;
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    rewind(file);

    char *contentFile = (char *)malloc(fileSize + 1);

    if (contentFile == NULL) {
        perror("Memory allocation error.\n");
        fclose(file);
        return 0;
    }

    size_t bytesRead = fread(contentFile, 1, fileSize, file);
    contentFile[bytesRead] = '\0';

    if (ferror(file)) {
        perror("Error reading file");
        free(contentFile);
        fclose(file);
        return 0;
    }

    char *ligne = strtok(contentFile, "\n");
    int identificationSuccessful = 0;

    while (ligne != NULL) {
        if (strstr(ligne, username) != NULL && strstr(ligne, motDePasse) != NULL) {
            identificationSuccessful = 1;
            break;
        }
        ligne = strtok(NULL, "\n");
    }

    free(contentFile);
    fclose(file);

    return identificationSuccessful;
}
void inscriptionFormateur() {
    int error = 0;
    struct Formateur *formateur = (struct Formateur *)malloc(sizeof(struct Formateur));

    if (formateur == NULL) {
        perror("Memory allocation failed");
        exit(EXIT_FAILURE);
    }

    do {
        printf("\t --->NOM: ");
        scanf(" %[^\n]", formateur->nom);

        printf("\t --->Prénom: ");
        scanf(" %[^\n]", formateur->prenom);

        printf("\t --->UserName: ");
        scanf(" %[^\n]", formateur->username);

        printf("\t --->Mot De Passe: ");
        scanf(" %[^\n]", formateur->motDePasse);

        if (identificateurCorrectfo(formateur->username, formateur->motDePasse) == 1) {
            printf("Compte Existant. Réessayer!\n");
            error = 1;
        }

        printf("\t --->Specialité: ");
        scanf(" %[^\n]", formateur->specialite);

        if (error == 0) {
            FILE *file = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Formateurs.txt", "a");

            if (file == NULL) {
                perror("Erreur ouverture du fichier.\n");
                free(formateur);
                exit(EXIT_FAILURE);
            }

            char newFormateur[500];
            snprintf(newFormateur, sizeof(newFormateur), "Nom Prénom:|%s %s| UserName:|%s| Mot De Passe:|%s| Specialité:|%s|\n",
                     formateur->nom, formateur->prenom, formateur->username, formateur->motDePasse, formateur->specialite);

            fputs(newFormateur, file);
            fclose(file);
            free(formateur);
        }
    } while (error == 1);

    printf("Bienvenue cher Formateur.\n");
    identificationFormateur();
}

void identificationFormateur() {
    int essais = 3;

    do {
        char username[20], motDePasse[20];

        printf(" __________________________\n");
        printf("|       UserName:          |\n");
        printf("|__________________________|\n");
        scanf("%19s", username);

        printf(" __________________________\n");
        printf("|      Mot De Passe:       |\n");
        printf("|__________________________|\n");
        scanf("%19s", motDePasse);

        if (identificateurCorrectfo(username, motDePasse) == 0) {
            essais--;
            if (essais > 0) {
                printf("Il vous reste %d essais\n", essais);
            } else {
                printf("Tentatives épuisées. Veuillez réessayer plus tard.\n");
                return ;
            }
        } else {
            menuOperationFormateur();
            return ;
        }
    } while (essais > 0);

    return ;
}

void menuFormateur(){
                  int choix;
                  do {
                      printf(" ___________________________________________________________\n");
                      printf("|  _                      _                                 |\n");
                      printf("| |_  _ ._   _.  _  _    |_ _  ._ ._ _   _. _|_  _      ._  | \n");
                      printf("| |_ _> |_) (_| (_ (/_   | (_) |  | | | (_|  |_ (/_ |_| |   |\n");
                      printf("|       |                                                   |\n");
                      printf("|___________________________________________________________|\n");
                      printf("|1. s'inscrire                                              |\n");
                      printf("|2. s'identifier                                            |\n");
                      printf("|0. Retour                                                  |\n");
                      printf("|___________________________________________________________|\n");
                      printf("\t --->Choix: ");
                      scanf("%d", &choix);

                      switch (choix) {
                          case 1:
                              inscriptionFormateur();
                              break;
                          case 2:
                              identificationFormateur();
                              break;
                          case 0:
                              printf("Retour au menu principal.\n");
                              break;
                          default:
                              printf("Choix invalide. Veuillez réessayer.\n");
                      }
                  } while (choix != 0);}

void menuOperationFormateur(){
                  int choix;
                  do {
                  printf(" ________________________________________________________\n");
                  printf("|---------- __   __  _______  __    _  __   __ ----------|\n");
                  printf("|----------|  |_|  ||       ||  |  | ||  | |  |----------|\n");
                  printf("|----------|       ||    ___||   |_| ||  | |  |----------|\n");
                  printf("|----------|       ||   |___ |       ||  |_|  |----------|\n");
                  printf("|----------|       ||    ___||  _    ||       |----------|\n");
                  printf("|----------| ||_|| ||   |___ | | |   ||       |----------|\n");
                  printf("|----------|_|   |_||_______||_|  |__||_______|----------|\n");
                  printf("|--------------------------------------------------------|\n");
                  printf("|1. Ajouter une formation.                               |\n");
                  printf("|2. Supprimer une formation.                             |\n");
                  printf("|3. Consulter la liste des formations.                   |\n");
                  printf("|4. Consulter la liste des candidats.                    |\n");
                  printf("|0. Retour                                               |\n");
                  printf("|________________________________________________________|\n");
                  printf("\t --->Choix: ");
                      scanf("%d", &choix);

                      switch (choix) {
                          case 1:
                              ajouterFormation();
                              break;
                          case 2:
                              supprimerFormation();
                              break;
                          case 3:
                              afficherListeFormationfo();
                              break;
                          case 4:
                              afficherListeCandidatfo();
                              break;
                          case 0:
                              printf("Retour au menu formateur.\n");
                              break;
                          default:
                              printf("Choix invalide. Veuillez réessayer.\n");
                      }
                  } while (choix != 0);}
