#ifndef FORMATION_H
#define FORMATION_H

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <time.h>

struct date{
int jour;
int mois;
int annee;
} ;
struct Formation {
    char titre[100];
    int duree;
    struct date dateDebut;
    struct date dateFin;
    float prix;
    char formateur[100];

};

int afficherListeFormation();
void supprimerLignef(const char *nomFichier, int indiceLigneASupprimer);
void ajouterFormation();
void supprimerFormation();

#endif // FORMATION_H


