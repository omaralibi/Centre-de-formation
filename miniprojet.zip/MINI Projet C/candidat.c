#include "formateur.h"
#include "formation.h"
#include "candidat.h"
#include "administration.h"

int inscriptionValide(const char *nomFormation) {
    FILE *file = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Formations.txt", "r");

    if (file == NULL) {
        perror("Erreur ouverture du fichier.\n");
        return -1;
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    rewind(file);

    char *contenuFile = (char *)malloc(fileSize + 1);

    if (contenuFile == NULL) {
        perror("Memory allocation error");
        fclose(file);
        return -1;
    }

    fread(contenuFile, 1, fileSize, file);
    contenuFile[fileSize] = '\0';

    char *ligne = strtok(contenuFile, "\n");

    while (ligne != NULL) {
        char formationNom[100];
        if (sscanf(ligne, "Titre de la formation:|%99[^|]|", formationNom) == 1) {
            if (strcmp(formationNom, nomFormation) == 0) {
                free(contenuFile);
                fclose(file);
                return 1; // Formation found
            }
        }
        ligne = strtok(NULL, "\n");
    }

    free(contenuFile);
    fclose(file);
    return 0; // Formation not found
}

void inscrirePourFormation() {
    afficherListeFormation();
if (afficherListeFormation()==1){
printf("\n__________________________\n");
printf("|    Nom de la Formation:  |\n");
printf("|__________________________|\n");

char nomFormation[100];
scanf(" %[^\n]", nomFormation);

    if (inscriptionValide(nomFormation)) {
    printf("\n_______________________________\n");
    printf("| Nom et Prénom du Candidat:    |\n");
    printf("|_______________________________|\n");

    char nomCandidat[100], nomFormateur[100];
    scanf(" %[^\n]", nomCandidat);

    printf("\n_________________________________\n");
    printf("| NOM et Prénom du Formateur:     |\n");
    printf("|_________________________________|\n");

    scanf(" %[^\n]", nomFormateur);
        FILE *file = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Inscriptions.txt", "a");
        if (file == NULL) {
            printf("Erreur ouverture du fichier.\n");
            return;
        }

        fprintf(file, "Formation:|%s| Formateur:|%s| Candidat|%s| _Non payée_\n", nomFormation, nomFormateur, nomCandidat);
        fclose(file);

        printf("Inscription réussie à la formation \"%s\".\n", nomFormation);
    } else {
        printf("Inscription invalide. Veuillez réessayer.\n");
    }
}}

int isLeapYearC(int year) {
    return ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
}

int isValidDateC(struct date *date) {
    if (date->mois < 1 || date->mois > 12) {
        return 0; // Invalid month
    }

    const int daysInMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (date->jour < 1 || date->jour > daysInMonth[date->mois]) {
        if (date->mois == 2 && isLeapYearC(date->annee) && date->jour == 29) {
            return 1;
        } else {
            return 0; // Invalid day
        }
    }

    return 1; // Valid date
}
void annulerInscription() {
    char formationAnnulee[100], nomCandidat[100];
    afficherListeInscriptions();

    printf("\n__________________________\n");
    printf("|    Nom de la Formation:  |\n");
    printf("|__________________________|\n");

    scanf(" %[^\n]", formationAnnulee);

    printf("\n__________________________\n");
    printf("|      Nom du Candidat:    |\n");
    printf("|__________________________|\n");

    scanf(" %[^\n]", nomCandidat);

    const char *fichierPath = "C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Inscriptions.txt";

    FILE *fichier = fopen(fichierPath, "r");
    if (fichier == NULL) {
        perror("Erreur lors de l'ouverture du fichier original");
        exit(EXIT_FAILURE);
    }

    FILE *fichierTemp = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", "w");
    if (fichierTemp == NULL) {
        perror("Erreur lors de l'ouverture du fichier temporaire");
        fclose(fichier);
        exit(EXIT_FAILURE);
    }

    fseek(fichier, 0, SEEK_END);
    long fichierSize = ftell(fichier);
    rewind(fichier);

    char *contentFile = (char *)malloc(fichierSize + 1);

    fread(contentFile, 1, fichierSize, fichier);
    contentFile[fichierSize] = '\0';

    char *ligne = strtok(contentFile, "\n");

    while (ligne != NULL) {
        if (strstr(ligne, formationAnnulee) != NULL && strstr(ligne, nomCandidat) != NULL) {
        } else {
            fprintf(fichierTemp, "%s\n", ligne);
        }

        ligne = strtok(NULL, "\n");
    }

    fclose(fichier);
    fclose(fichierTemp);
    free(contentFile);

    if (remove(fichierPath) != 0) {
        remove("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt");
        perror("Erreur lors de la suppression du fichier original");
        exit(EXIT_FAILURE);
    }

    if (rename("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", fichierPath) != 0) {
        perror("Erreur lors du renommage du fichier temporaire");
        exit(EXIT_FAILURE);
    }

    printf("Inscription annulée pour la formation \"%s\" par le candidat \"%s\".\n", formationAnnulee, nomCandidat);
    afficherListeFormation();
}
int identificateurCorrectc(const char *mail, const char *motDePasse) {
    FILE *file = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Candidats.txt", "r");

    if (file == NULL) {
        perror("Erreur ouverture du fichier.\n");
        return 0;
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    rewind(file);

    char *contenuFile = (char *)malloc(fileSize + 1);

    if (contenuFile == NULL) {
        perror("Memory allocation failed");
        fclose(file);
        return 0;
    }

    size_t bytesRead = fread(contenuFile, 1, fileSize, file);
    contenuFile[bytesRead] = '\0';

    if (ferror(file)) {
        perror("Error reading file");
        free(contenuFile);
        fclose(file);
        return 0;
    }

    char *ligne = strtok(contenuFile, "\n");
    int identificationSuccessful = 0;

    while (ligne != NULL) {
        if (strstr(ligne, mail) != NULL && strstr(ligne, motDePasse) != NULL) {
            identificationSuccessful = 1;
            break;
        }
        ligne = strtok(NULL, "\n");
    }

    free(contenuFile);
    fclose(file);

    return identificationSuccessful;
}
void supprimerSonCompte() {
    char mail[100];
    char motDePasse[100];
    const char *fichierPath = "C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Candidats.txt";

    printf(" __________________________\n");
    printf("|       Email:             |\n");
    printf("|__________________________|\n");
    scanf(" %99s", mail);

    printf(" __________________________\n");
    printf("|      Mot De Passe:       |\n");
    printf("|__________________________|\n");
    scanf(" %[\n]", motDePasse);

    if (identificateurCorrectc(mail, motDePasse) == 1) {
        FILE *fichier = fopen(fichierPath, "r");
        FILE *fichierTemp = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", "w");

        if (fichier == NULL || fichierTemp == NULL) {
            perror("Erreur lors de l'ouverture des fichiers");
            exit(EXIT_FAILURE);
        }

        fseek(fichier, 0, SEEK_END);
        long fichierSize = ftell(fichier);
        rewind(fichier);

        char *contenuFile = (char *)malloc(fichierSize + 1);

        if (contenuFile == NULL) {
            perror("Memory allocation error");
            fclose(fichier);
            fclose(fichierTemp);
            exit(EXIT_FAILURE);
        }

        fread(contenuFile, 1, fichierSize, fichier);
        contenuFile[fichierSize] = '\0';

        char *ligne = strtok(contenuFile, "\n");

        while (ligne != NULL) {
            if (strstr(ligne, mail) != NULL && strstr(ligne, motDePasse) != NULL) {
            } else {
                fprintf(fichierTemp, "%s\n", ligne);
            }
            ligne = strtok(NULL, "\n");
        }

        fclose(fichier);
        fclose(fichierTemp);
        free(contenuFile);

        if (remove(fichierPath) != 0) {
            perror("Erreur lors de la suppression du fichier original");
            exit(EXIT_FAILURE);
        }

        if (rename("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/temp.txt", fichierPath) != 0) {
            perror("Erreur lors du renommage du fichier temporaire");
            exit(EXIT_FAILURE);
        }
    }

    return;
}
void menuOperationCandidat(){
                  int choix,deleted=0;
                  do {
                  printf("\n ________________________________________________________\n");
                  printf("|---------- __   __  _______  __    _  __   __ ----------|\n");
                  printf("|----------|  |_|  ||       ||  |  | ||  | |  |----------|\n");
                  printf("|----------|       ||    ___||   |_| ||  | |  |----------|\n");
                  printf("|----------|       ||   |___ |       ||  |_|  |----------|\n");
                  printf("|----------|       ||    ___||  _    ||       |----------|\n");
                  printf("|----------| ||_|| ||   |___ | | |   ||       |----------|\n");
                  printf("|----------|_|   |_||_______||_|  |__||_______|----------|\n");
                  printf("|--------------------------------------------------------|\n");
                  printf("|1. Consulter la liste des formations.                   |\n");
                  printf("|2. S'inscrire à une formation.                         |\n");
                  printf("|3. Annuler une inscription.                             |\n");
                  printf("|4. Supprimer le compte.                                 |\n");
                  printf("|0. Retour                                               |\n");
                  printf("|________________________________________________________|\n");
                  printf("\t --->Choix: ");
                      scanf("%d", &choix);

                      switch (choix) {
                          case 1:
                              afficherListeFormation();
                              break;
                          case 2:
                              inscrirePourFormation();
                              break;
                          case 3:
                            annulerInscription();
                            break;
                          case 4:
                              supprimerSonCompte();
                              deleted=1;
                              break;
                          case 0:
                              printf("Retour au menu candidat.\n");
                              break;
                          default:
                              printf("Choix invalide. Veuillez réessayer.\n");
                      }
                  } while ((choix != 0)&&(deleted==0));}

void identificationCandidat() {
    int essais = 3;

    do {
        char mail[30], motDePasse[20];

        printf(" __________________________\n");
        printf("|       Email:             |\n");
        printf("|__________________________|\n");
        scanf("%29s", mail);

        printf(" __________________________\n");
        printf("|      Mot De Passe:       |\n");
        printf("|__________________________|\n");
        scanf("%19s", motDePasse);

        if (identificateurCorrectc(mail, motDePasse) == 0) {
            essais--;
            if (essais > 0) {
                printf("Il vous reste %d essais\n", essais);
            } else {
                printf("Tentatives épuisées. Veuillez réessayer plus tard.\n");
                return ;
            }
        } else {
            menuOperationCandidat();
            return ;
        }

    } while (essais > 0);

    return ;
}
void inscriptionCandidat() {
    int error = 0;
    struct Candidat *candidat = (struct Candidat *)malloc(sizeof(struct Candidat));

    if (candidat == NULL) {
        perror("Memory allocation failed");
        exit(EXIT_FAILURE);
    }

    do {
        printf("\t --->NOM: ");
        scanf(" %[^\n]", candidat->nom);

        printf("\t --->Prénom: ");
        scanf("  %[^\n]", candidat->prenom);

        printf("\t --->Numéro telephonique: ");
        scanf("%ld", &candidat->telephone);

        printf("\t --->Date de Naissance:\n");
        printf("\t \t--->Jour: ");
        scanf(" %d", &candidat->dateDeNaissance.jour);
        printf("\t \t--->Mois: ");
        scanf(" %d", &candidat->dateDeNaissance.mois);
        printf("\t \t--->Année: ");
        scanf(" %d", &candidat->dateDeNaissance.annee);

        printf("\t --->Email: ");
        scanf("  %[^\n]", candidat->mail);

        printf("\t --->Mot De Passe: ");
        scanf("  %[^\n]", candidat->motDePasse);

        if (!isValidDateC(&candidat->dateDeNaissance) || identificateurCorrectc(candidat->mail, candidat->motDePasse) == 1) {
            printf("Informations invalides. Réessayer!\n");
            error = 1;
        } else {
            FILE *file = fopen("C:/Users/omara/OneDrive/Desktop/mini projet c version cb/baseDeDonnees/BD_Candidats.txt", "a");

            if (file == NULL) {
                perror("Erreur ouverture du fichier.\n");
                free(candidat);
                exit(EXIT_FAILURE);
            }

            fprintf(file, "NOM Prénom:|%s %s| Téléphone:|+216 %ld| Date de naissance:|%d/%d/%d| Email:|%s| Mot de passe:|%s|\n",
                    candidat->nom, candidat->prenom, candidat->telephone,
                    candidat->dateDeNaissance.jour, candidat->dateDeNaissance.mois, candidat->dateDeNaissance.annee,
                    candidat->mail, candidat->motDePasse);

            fclose(file);
            free(candidat);
            error = 0;
        }
    } while (error != 0);

    if (error == 0) {
        printf("Bienvenue cher Candidat.\n");
        identificationCandidat();
    }
}

void menuCandidat(){
                 int choix;
                  do {
                      printf(" ________________________________________________________\n");
                      printf("|  _                      _                              |\n");
                      printf("| |_  _ ._   _.  _  _    /   _. ._   _| o  _|  _. _|_    | \n");
                      printf("| |_ _> |_) (_| (_ (/_   |_ (_| | | (_| | (_| (_|  |_    |\n");
                      printf("|       |                                                |\n");
                      printf("|________________________________________________________|\n");
                      printf("|1. s'inscrire                                           |\n");
                      printf("|2. s'identifier                                         |\n");
                      printf("|0. Retour                                               |\n");
                      printf("|________________________________________________________|\n");
                      printf("\t --->Choix: ");
                      scanf("%d", &choix);

                      switch (choix) {
                          case 1:
                              inscriptionCandidat();
                              break;
                          case 2:
                              identificationCandidat();
                              break;
                          case 0:
                              printf("Retour au menu principal.\n");
                              break;
                          default:
                              printf("Choix invalide. Veuillez réessayer.\n");
                      }
                  } while (choix != 0); return;}

