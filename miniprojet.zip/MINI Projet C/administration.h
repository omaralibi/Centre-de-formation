#ifndef ADMIN_H
#define ADMIN_H

#include "formation.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>




int afficherListeCandidatAd();
int afficherListeFormateurAd();
void menuAdministration();
void supprimerFormateur();
void supprimerCandidat();
void afficherListeInscriptions();
void changerStatutInscription();

#endif // ADMIN_H

