#ifndef CANDIDAT_H
#define CANDIDAT_H
#include "formation.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>



struct Candidat {
    char nom[50];
    char prenom[50];
    struct date dateDeNaissance;
    char mail[100];
    long int telephone;
    char motDePasse[100];
};
void menuCandidat();
void inscriptionCandidat();
void identificationCandidat();
void supprimerSonCompte();
void menuOperationCandidat();
int identificateurCorrectc(const char *mail, const char *motDePasse);
int isValidDateC(struct date *date);
int isLeapYearC(int year);
void inscrirePourFormation();
int inscriptionValide(const char *nomFormation);
void annulerInscription();
#endif // CANDIDAT_H




